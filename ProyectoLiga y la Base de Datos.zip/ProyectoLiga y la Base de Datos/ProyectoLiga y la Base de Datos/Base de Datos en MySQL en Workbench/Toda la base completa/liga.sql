-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: liga
-- ------------------------------------------------------
-- Server version	5.6.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alineacion`
--

DROP TABLE IF EXISTS `alineacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alineacion` (
  `id_partido` tinyint(2) NOT NULL,
  `id_jugador` tinyint(2) NOT NULL,
  `inicio` time NOT NULL,
  `fin` time NOT NULL,
  `puesto` enum('titular','cambio','banca') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alineacion`
--

LOCK TABLES `alineacion` WRITE;
/*!40000 ALTER TABLE `alineacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `alineacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipo`
--

DROP TABLE IF EXISTS `equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  `mascota` varchar(20) DEFAULT NULL,
  `estadio` varchar(20) NOT NULL,
  `ciudad` varchar(20) NOT NULL,
  `partidos_jugados` tinyint(2) DEFAULT NULL,
  `partidos_ganados` tinyint(2) NOT NULL,
  `partidos_empatados` tinyint(2) NOT NULL,
  `partidos_perdidos` tinyint(2) NOT NULL,
  `goles_favor` tinyint(2) NOT NULL,
  `goles_encontra` tinyint(2) NOT NULL,
  `diferencia_goles` tinyint(2) NOT NULL,
  `puntos` tinyint(2) NOT NULL,
  `liga` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_liga` (`liga`),
  CONSTRAINT `fk_liga` FOREIGN KEY (`liga`) REFERENCES `equipo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo`
--

LOCK TABLES `equipo` WRITE;
/*!40000 ALTER TABLE `equipo` DISABLE KEYS */;
INSERT INTO `equipo` VALUES (1,'Guadalajara','Chiva','Omnilife','Zapopan',10,4,6,3,21,14,7,18,1),(2,'Atlas Guadalajara','Zorro','Estadio Jalisco','Guadalajara',10,1,6,3,14,24,-10,9,1),(3,'Leon','Leon','Now Camp','Leon',10,6,1,3,23,17,6,22,1),(4,'Morelia','Monarca','Morelos','Michoacan',10,2,4,3,19,20,-1,19,1),(5,'Queretaro','Gallo','Correjidora','Queretaro',10,2,2,6,15,19,-4,13,1),(6,'Toluca','Diablo','Nemesio Diez','Toluca',10,2,4,4,13,16,-3,13,1),(7,'Veracruz','Tiburon','Pirata Fuente','Veracruz',10,1,6,3,13,27,-14,10,1),(8,'Chiapas','Jaguar','Manuel Reyna','Tuxtla Gutierrez',10,3,2,4,13,24,-11,12,1),(9,'Puebla','Camote','Cuauhtemoc','Puebla',10,3,5,2,15,20,-5,15,1),(10,'Pachuca','Pachus','Hidalgo','Pachuca',10,5,3,2,28,13,15,25,1),(11,'Tigres','Tigre','Universitario','San Nicolas',10,4,3,3,20,15,5,17,1),(12,'Monterrey','Monty','BBVA Bancomer','Monterrey',10,8,0,2,29,15,14,30,1),(13,'Santos','Apache','Corona','Torreon',10,5,2,3,17,15,2,21,1),(14,'Tijuana','Xoloitzcuintle','Caliente','Tijuana',10,3,6,1,15,21,-6,16,1),(15,'Dorados','Dorado','Banorte','Culiacan',10,1,1,8,14,24,-10,11,1),(16,'America','Aguila','Azteca','Ciudad de Mexico',10,5,3,2,30,16,14,27,1),(17,'Unam','Puma','Olimpico','Ciudad de Mexico',10,2,6,2,16,19,-3,15,1),(18,'Cruz azul','Conejo','Azul','Ciudad de Mexico',10,3,6,1,22,18,4,19,1),(19,'Indios','Indio','Los Altos','Monterrey',20,17,2,1,11,8,3,22,1),(20,'Indios','Indio','Los Altos','Monterrey',20,17,2,1,11,8,3,22,1),(21,'Indios','Indio','Los Altos','Monterrey',20,17,2,1,11,8,3,22,1);
/*!40000 ALTER TABLE `equipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jugador`
--

DROP TABLE IF EXISTS `jugador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jugador` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `paterno` varchar(20) NOT NULL,
  `materno` varchar(20) DEFAULT NULL,
  `nombre` varchar(20) NOT NULL,
  `posicion` varchar(20) NOT NULL,
  `numero` tinyint(2) NOT NULL,
  `tarjetas_amarillas` tinyint(2) NOT NULL,
  `tarjetas_rojas` tinyint(2) NOT NULL,
  `goles` tinyint(2) NOT NULL,
  `equipo` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_equipo` (`equipo`)
) ENGINE=InnoDB AUTO_INCREMENT=494 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jugador`
--

LOCK TABLES `jugador` WRITE;
/*!40000 ALTER TABLE `jugador` DISABLE KEYS */;
INSERT INTO `jugador` VALUES (1,'Cota','Robles','Rodolfo','Portero',30,0,0,5,1),(2,'Rodriguez','Romero','Jose','Portero',1,0,0,6,1),(3,'Jimenez','Ponce','Miguel','Portero',34,0,0,2,1),(4,'Lopez','Gomez','Raul','Defensa',15,0,0,0,1),(5,'Salcedo','Hernandez','Carlos','Defensa',13,4,1,0,1),(6,'Pereira','Rodriguez','Jair','Defensa',4,3,1,1,1),(7,'Hernandez','Herrera','Edwin','Defensa',6,0,0,0,1),(8,'Salcido','Flores','Carlos','Defensa',3,0,0,0,1),(9,'Ponce','Briseno','Miguel','Defensa',16,1,0,0,1),(10,'Marin','Arroyo','Edgardo','Defensa',4,1,0,0,1),(11,'Basulto','Medina','Juan','Defensa',28,1,0,0,1),(12,'Villanueva','Lopez','Carlos','Defensa',27,0,0,0,1),(13,'Alanis','Pantoja','Oswaldo','Defensa',2,0,0,0,1),(14,'Pineda','Alvarado','Orbelin','Medio',7,2,0,2,1),(15,'Brizuela','Munoz','Isaac','Medio',11,0,0,1,1),(16,'Cisneros','Barajas','Carlos','Medio',24,1,1,2,1),(17,'Pena','Rodriguez','Carlos','Medio',26,1,0,3,1),(18,'Perez','Ortiz','Michael','Medio',25,3,0,0,1),(19,'Castro','Macias','Israel','Medio',20,1,0,0,1),(20,'Ramirez','Garcia','Jose','Medio',21,0,0,0,1),(21,'Lopez','Ramirez','Javier','Medio',31,0,0,0,1),(22,'Hernandez','Neri','Giovani','Medio',18,0,0,0,1),(23,'Casillas','Chavez','Giovani','Medio',32,0,0,0,1),(24,'Sanchez','Garcia','Jesus','Medio',17,0,0,0,1),(25,'Reyna','Martinez','Angel','Medio',10,0,0,0,1),(26,'Zaldivar','Caviedes','Angel','Delantero',23,0,0,0,1),(27,'Bravo','Tordecillas','Omar','Delantero',9,2,0,0,1),(28,'Vazquez','Gallien','Ricardo','Delantero',19,0,0,0,1),(29,'Fraga','Licona','Miguel Angel','Portero',30,0,0,0,2),(30,'Ustari','Alfred','Oscar','Portero',1,1,0,0,2),(31,'Hernandez','Garcia','Jose Antonio','Portero',127,0,0,0,2),(32,'Kannemann','Kannemann','Walter','Defensa',5,4,0,0,2),(33,'Leon','Rodriguez','Francisco','Defensa',3,1,0,0,2),(34,'Marquez','Alvarez','Rafael','Defensa',4,3,0,1,2),(35,'Salinas','Dorantes','Rodrigo','Defensa',29,5,0,1,2),(36,'Aguirre','Ledesma','Gaddi','Defensa',127,1,0,0,2),(37,'Baloy','Ramirez','Felipe Abdiel','Defensa',23,2,0,0,2),(38,'Nava','Garcia','Julio','Defensa',20,1,0,0,2),(39,'Maduena','Lopez','Antonio','Defensa',25,0,0,0,2),(40,'Arreola','Rodriguez','Carlos','Defensa',100,0,0,0,2),(41,'Mascarenas','Avendano','Pablo','Medio',22,0,0,0,2),(42,'Arevalo','Rios','Egidio','Medio',16,1,0,0,2),(43,'Gonzalez','Gonzalez','Arturo','Medio',15,1,0,2,2),(44,'Medina','Alonzo','Juan','Medio',26,4,0,2,2),(45,'Villalpando','Perez','Dieter','Medio',18,1,0,1,2),(46,'Gonzalez','Luengo','Alvaro','Medio',32,1,1,0,2),(47,'Gaspar','Hernandez','Angel','Medio',24,1,0,0,2),(48,'Salinas','Ortiz','Rodolfo','Medio',17,0,0,0,2),(49,'Rodriguez','Mata','Luis','Medio',21,0,0,0,2),(50,'Bergessio','Bergessio','Ruben','Delantero',9,3,1,3,2),(51,'Arizala','Hurtado','Franco','Delantero',11,1,0,0,2),(52,'Duque','Montoya','Jefferso','Delantero',10,1,0,1,2),(53,'Alvarez','Lopez','Daniel','Delantero',8,0,0,0,2),(54,'Barragan','Negrete','Martin','Delantero',28,0,0,0,2),(55,'Hernandez','Trejo','Daniel','Delantero',14,0,0,0,2),(56,'Rivera','Vargas','Edson','Delantero',7,0,0,0,2),(57,'Vazquez','null',' Ricardo Michel ','Delantero',19,0,0,0,2),(58,'Granados','null',' Marco ','Delantero',83,0,0,0,2),(59,'Yarbrough','null','William Paul ','Portero',25,1,0,0,3),(60,'Martinez','null','Christian','Portero',16,0,0,0,3),(61,'Rios','null','Cesar Alejandro','Portero',28,0,0,0,3),(62,'Navarro','null','Fernando','Defensa',5,5,0,2,3),(63,'Burdisso','null','Guillermo','Defensa',3,0,0,1,3),(64,'Velarde','null','Efrain','Defensa',2,1,0,0,3),(65,'Novaretti','null','Diego','Defensa',6,0,0,1,3),(66,'Gonzalez','null','Juan Ignacio','Defensa',35,2,0,0,3),(67,'Magallon','null','Jonny','Defensa',19,0,0,0,3),(68,'Torres','null','Cristian','Defensa',4,0,0,0,3),(69,'Lopez','null','Ricardo','Defensa',21,0,0,0,3),(70,'Hernandez','null','Elias Hernan','Medio',8,0,0,2,3),(71,'Rocha','null','Aldo','Medio',29,4,0,1,3),(72,'Montes','null','Luis','Medio',10,2,0,0,3),(73,'Enriquez','null','Jorge','Medio',15,0,0,0,3),(74,'Vazquez','null','Jose Juan','Medio',23,1,0,0,3),(75,'Gonzales','null','Jonathan David','Medio',31,0,0,0,3),(76,'Lopez','null','Leonel','Medio',13,0,0,0,3),(77,'Ibarra','null','Miguel','Medio',14,0,0,0,3),(78,'Moralez','null','Maximiliano','Delantero',18,1,0,2,3),(79,'Cano','null','German Ezequiel','Delantero',9,3,0,4,3),(80,'Burbano','null','Hernan Dario','Delantero',7,1,0,0,3),(81,'Cuevas','null','Juan Ezequiel','Delantero',22,1,0,0,3),(82,'Boselli','null','Mauro','Delantero',17,0,0,5,3),(83,'Bueno','null','Marco Antonio','Delantero',11,0,0,0,3),(84,'Rodriguez','null','Carlos Felipe','Portero',1,1,0,15,4),(85,'Saucedo','null','Cirilo','Portero',13,0,0,0,4),(86,'Espinoza','null','Ignacio Gonzalez','Defensa',30,1,0,0,4),(87,'Morales','null','Carlos','Defensa',28,2,0,1,4),(88,'Perez','null','Enrique','Defensa',2,2,0,1,4),(89,'Erpen','null','Facundo','Defensa',5,3,0,0,4),(90,'Loeschbor','null','Emanuel','Defensa',17,0,0,0,4),(91,'Torsiglieri','null','Marco Natanel','Defensa',4,0,0,0,4),(92,'Olvera','null','Jose Antonio','Defensa',3,0,0,0,4),(93,'Altamira','null','Santiago','Defensa',29,0,0,0,4),(94,'Pellerano','null','Cristian','Medio',16,2,0,1,4),(95,'Aguirre','null','Erick','Medio',21,0,0,0,4),(96,'Zamorano','null','Armando','Medio',22,0,0,0,4),(97,'Loboa','null','Eisner Ivan','Medio',19,0,0,0,4),(98,'Gagliardi','null','Alejandro','Medio',10,0,0,1,4),(99,'Zarate','null','Jorge Alejandro','Medio',11,1,0,0,4),(100,'Millar','null','Rodrigo Javier','Medio',20,0,0,2,4),(101,'Rodriguez','null','Juan Pablo','Medio',8,1,0,1,4),(102,'Vilchis','null','Rodolfo','Medio',12,0,0,0,4),(103,'Rey','null','Luis Gabriel','Delantero',18,0,0,1,4),(104,'Velazquez','null','Pablo','Delantero',7,3,0,2,4),(105,'Cuero','null','Jefferson','Delantero',23,2,1,0,4),(106,'Sansores','null','Miguel Angel','Delantero',27,0,0,0,4),(107,'Hernandez','Tellez','Edgar Adolfo','Portero',23,1,0,0,5),(108,'Thiago','Volpi','Luis','Portero',31,1,0,0,5),(109,'Alcala','Barba','Gil Esaul','Portero',33,0,0,0,5),(110,'Corral','Ang','George Ulises','Defensa',2,0,0,0,5),(111,'Angel','Martinez','Miguel','Defensa',3,2,0,0,5),(112,'Escalante','Moreno','Dionicio Manuel','Defensa',4,0,0,0,5),(113,'Corona','Delgado','Yasser Anwar','Defensa',5,3,0,1,5),(114,'Daniel','Forlin','Juan','Defensa',6,2,0,1,5),(115,'Rey','Borsntein','Jhonathan','Defensa',12,0,0,0,5),(116,'Milke','Almagran','Victor Manuel','Defensa',13,1,0,0,5),(117,'Esqueda','Ornelas','Luis Ricardo','Defensa',18,0,0,1,5),(118,'Miguel','Gil','Luis','Medio',8,1,0,0,5),(119,'Matias','Naelson','Antonio Sinha','Medio',10,0,0,0,5),(120,'Noriega','Orozco','Luis Miguel','Medio',14,3,0,1,5),(121,'Nery','Dominguez','Andres','Medio',14,1,0,1,5),(122,'Osuna','Pereznunez','Mario Humberto','Medio',17,1,0,0,5),(123,'Candelo','Miranda','Yerson','Medio',19,1,1,0,5),(124,'Jimenez','GonzaLes','Marco Antonio','Medio',21,0,0,1,5),(125,'Gomez','Valencia','Jaime','Medio',28,1,0,0,5),(126,'Da Silva','Sanvezzo','Camilo','Delantero',7,0,0,1,5),(127,'Fierro','Guerrero','Carlos Eduardo','Delantero',9,0,0,2,5),(128,'Sepulveda','Sanchez','Angel Baltazar','Delantero',15,4,0,0,5),(129,'Benitez','Santander','Edgar','Delantero',24,0,0,1,5),(130,'Madrigal','Gutierrez','Luis Guillermo','Delantero',27,0,0,0,5),(131,'villa','Emanuel','Alejandro','Delantero',30,3,0,2,5),(132,'Talavera','null','Alfredo','Portero',1,2,0,16,6),(133,'Sanchez','null','Liborio Vicente','Portero',22,0,0,0,6),(134,'Centeno','null','Miguel Angel','Portero',12,0,0,0,6),(135,'Rodriguez','null','Carlos Gerardo','Defensa',16,1,0,0,6),(136,'Da Silva','null','Paulo','Defensa',4,1,0,1,6),(137,'Galindo','null','Aaron','Defensa',3,0,0,0,6),(138,'Ortiz','null','Richard','Defensa',14,2,1,1,6),(139,'Flores','null','Gerardo','Defensa',33,2,1,0,6),(140,'Silva','null','Jordan','Defensa',30,1,0,0,6),(141,'Rojas','null','Oscar Ricardo','Defensa',6,0,0,0,6),(142,'Gamboa','null','Francisco','Defensa',2,0,0,0,6),(143,'Quezada','null','Mario Alberto','Defensa',27,1,0,0,6),(144,'Heredia','null','Gerardo','Defensa',84,0,0,0,6),(145,'Perez','null','Christian','Defensa',5,0,0,0,6),(146,'Cueva','null','Christian Alberto','Medio',13,0,0,2,6),(147,'Rios','null','Antonio','Medio',15,3,0,0,6),(148,'Bottinelli','null','Dario','Medio',18,2,0,0,6),(149,'Lobos','null','Lucas','Medio',10,0,0,0,6),(150,'Velasco','null','Moises Adrian','Medio',7,1,0,0,6),(151,'Brambila','null','Edy German','Medio',19,1,0,0,6),(152,'Trejo','null','Erbin Alejandro','Medio',26,0,0,0,6),(153,'Esquivel','null','Carlos','Medio',11,0,0,0,6),(154,'Triverio','null','Enrique Luis','Medio',21,4,0,6,6),(155,'Himcapie','null','Fernando Uribe','Medio',20,2,0,1,6),(156,'Riveron','null','Omar Arellano','Medio',23,1,0,0,6),(157,'Saucedo','null','Roberto Nicolas','Medio',8,0,0,1,6),(158,'Vega','null','Ernesto','Medio',29,1,0,0,6),(159,'Gama','null','Diego Alberto','Medio',17,0,0,0,6),(160,'Hernandez','null','Edgar Meliton','Portero',13,0,0,9,7),(161,'Garcia','null','Sergio Alejandro','Portero',33,0,0,8,7),(162,'Lopez','null','Leobardo','Defensa',23,2,0,1,7),(163,'Paganoni','null','Jesus Arturo','Defensa',28,2,0,0,7),(164,'Noya','null','Rodrigo Javier','Defensa',24,4,1,0,7),(165,'Calvo','null','Carlos','Defensa',3,0,0,0,7),(166,'Cid','null','Hugo','Defensa',29,0,0,0,7),(167,'Cervantes','null','Horacio','Defensa',12,1,0,2,7),(168,'Godinez','null','Rodrigo','Defensa',4,1,0,0,7),(169,'Berber','null','Alejandro','Defensa',21,0,0,0,7),(170,'Chavez','null','Darvin Francisco','Defensa',5,0,0,0,7),(171,'Cardenas','null','Carlos','Defensa',32,0,0,0,7),(172,'Andrade','null','Edgar','Medio',18,2,0,2,7),(173,'Meneses','null','Fernando','Medio',20,1,0,0,7),(174,'Penalba','null','Gabriel','Medio',8,4,2,2,7),(175,'Lopez','null','Emilio','Medio',0,2,0,0,7),(176,'Zamora','null','Alan Miguel','Medio',7,1,0,0,7),(177,'Vera','null','Oscar Salvador','Medio',22,0,0,0,7),(178,'Martinez','null','Luis Antonio','Medio',6,0,0,0,7),(179,'Fernandez','null','Juan','Medio',25,0,0,0,7),(180,'Lugo','null','Edgar Gerardo','Medio',0,0,0,0,7),(181,'Saucedo','null','Sebastian','Medio',17,0,0,0,7),(182,'Chavez','null','Diego','Medio',29,0,0,0,7),(183,'de la Pena','null','Cesar','Medio',0,0,0,0,7),(184,'Hutt','null','Pablo','Medio',0,0,0,0,7),(185,'Furch','null','Julio','Delantero',11,3,0,3,7),(186,'Villalva','null','Daniel','Delantero',9,1,1,1,7),(187,'Albin','null','Juan Angel','Delantero',10,1,0,1,7),(188,'Esqueda','null','Enrique','Delantero',16,1,0,1,7),(189,'Martinez','null','Cristian','Delantero',19,0,0,0,7),(190,'Tafolla','null','Salvador','Delantero',30,0,0,0,7),(191,'Manzo','null','Inri','Delantero',31,0,0,0,7),(192,'Jimenez','null','Oscar','Portero',21,0,0,13,8),(193,'Rodriguez','null','Jesus Ivan','Portero',30,0,0,0,8),(194,'Villalpando','null','Jorge','Portero',1,0,0,0,8),(195,'Munoz','null','Javier David','Defensa',2,1,0,0,8),(196,'Paredes','null','WilliamParedes','Defensa',3,3,0,0,8),(197,'Venegas','null','Luis Gerardo','Defensa',4,2,1,1,8),(198,'Vigon','null','Juan Pablo','Defensa',22,1,0,0,8),(199,'Araujo','null','Felix','Defensa',20,1,1,0,8),(200,'Rodriguez','null','Luis Alfonso','Defensa',24,0,0,1,8),(201,'Zamora','null','Alonso','Defensa',17,0,0,0,8),(202,'Insaurralde','null','Juan','Defensa',29,3,0,0,8),(203,'Lopez','null','Carlos Humberto','Defensa',16,0,0,0,8),(204,'Sandez','null','Edwin','Defensa',91,0,0,0,8),(205,'Armenteros','null','Emiliano Daniel','Medio',35,3,0,2,8),(206,'Silva','null','Francisco','Medio',6,4,1,0,8),(207,'Andrade','null','David','Medio',28,0,0,0,8),(208,'de la Torre','null','Diego','Medio',5,0,0,0,8),(209,'Damasceno','null','Murilo','Medio',99,0,0,0,8),(210,'Cruz','null','Ricardo','Medio',32,0,0,0,8),(211,'Jimenez','null','Daniel','Medio',33,0,0,0,8),(212,'Vega','null','Daniel Gonzalez','Medio',19,0,0,0,8),(213,'Hurtado','null','Aviles','Delantero',18,1,0,1,8),(214,'Romero','null','Silvio','Delantero',10,1,0,6,8),(215,'Veron','null','Danilo','Delantero',11,2,0,0,8),(216,'Canelo','null','Alexis','Delantero',7,1,0,1,8),(217,'Marin','null','Adrian','Delantero',9,1,0,0,8),(218,'Lorona','null','Luis Guadalupe','Delantero',14,0,0,0,8),(219,'Campestrini','null','Cristian','Portero',17,5,1,11,9),(220,'Villasenor','null','Fabian Israel','Portero',1,0,0,4,9),(221,'Guerrero','null','Austin Henry','Portero',30,0,0,0,9),(222,'Gutierrez','null','Carlos Alberto','Defensa',3,0,0,0,9),(223,'Rojas','null','Oscar','Defensa',12,0,0,0,9),(224,'Herrera','null','Robert','Defensa',2,1,0,0,9),(225,'Duenas','null','Edgar','Defensa',5,0,0,0,9),(226,'Juarez','null','Roberto Carlos','Defensa',26,0,0,0,9),(227,'Arias','null','Ramon','Defensa',21,0,0,0,9),(228,'Merchant','null','Abraham Ruiz','Defensa',94,1,0,0,9),(229,'Yamin','null','Emilio','Defensa',14,0,0,0,9),(230,'Perez','null','Sergio','Defensa',24,0,0,0,9),(231,'Araujo','null','Patricio','Medio',22,3,0,1,9),(232,'Toledo','null','David','Medio',16,1,0,0,9),(233,'Ramirez','null','Luis Robles','Medio',8,2,0,0,9),(234,'Bermudez','null','Christian','Medio',10,0,0,2,9),(235,'Valdez','null','Christian','Medio',23,1,0,2,9),(236,'Santos','null','Flavio Jesus','Medio',19,1,0,0,9),(237,'Torres','null','Francisco','Medio',28,2,1,0,9),(238,'Escudero','null','Damian','Medio',29,0,0,1,9),(239,'Acosta','null','Alberto Joshimar','Medio',27,1,0,1,9),(240,'Ceballos','null','Sergio','Medio',4,0,0,0,9),(241,'Fassi','null','Juan Pablo','Medio',25,0,0,0,9),(242,'Juraidini','null','Alfredo','Medio',15,0,0,0,9),(243,'Alustiza','null','Matias','Delantero',11,2,0,5,9),(244,'Navarro','null','Alvaro Damian','Delantero',20,1,0,2,9),(245,'Cejas','null','Mauro','Delantero',9,0,1,0,9),(246,'Orrantia','null','Carlos Emilio','Delantero',7,0,0,0,9),(247,'Amione','null','Jeronimo','Delantero',13,1,0,0,9),(248,'Perez','null','Eduardo','Delantero',18,0,0,0,9),(249,'Marrufo','null','Omar','Delantero',82,0,0,0,9),(250,'Alfonso','Blanco','Antunez','Portero',1,0,0,0,10),(251,'Oscar','Perez','Rojas','Portero',24,0,0,1,10),(252,'Rafael','Ramirez','Miranda','Defensa',2,0,1,0,10),(253,'Omar','Esparza','Morales','Defensa',3,2,1,2,10),(254,'Omar','Alejandro','Gonzalez','Defensa',81,6,3,0,10),(255,'Victor','Guzman','Guzman','Defensa',15,1,0,0,10),(256,'Hector','Lopez','Garcia','Defensa',21,3,0,0,10),(257,'Stefan','Medina','Ramirez','Defensa',26,2,1,0,10),(258,'Aquivaldo','Mosquera','Romana','Defensa',54,0,3,0,10),(259,'Fabian','Murillo','Murillo','Defensa',63,0,1,0,10),(260,'Francisco','Pena','Lopez','Defensa',6,4,5,0,10),(261,'Osvaldo','Rodriguez','Portal','Medio',42,1,1,0,10),(262,'Steven','Almeida','Trinidad','Medio',13,2,2,1,10),(263,'Javier','Flores','Ibarra','Medio',56,4,0,0,10),(264,'Emmanuel','Garcia','Vaca','Medio',14,0,0,0,10),(265,'Gabriel','Gutierrez','Galaviz','Medio',23,7,0,0,10),(266,'Franco','Daniel','Jara','Medio',67,6,1,0,10),(267,'Antonio','Silva','Oliveira','Medio',49,0,3,1,10),(268,'Joaquin','Martinez','Valadez','Medio',50,2,1,0,10),(269,'Alejandro','Mascorro','Lopez','Medio',61,3,0,0,10),(270,'Isaac','Rodriguez','O','Medio',51,2,0,0,10),(271,'Jovanni','Rojas','Jimenez','Medio',9,4,3,0,10),(272,'Jose','Villegas','Cruz','Medio',10,2,1,0,10),(273,'Alejandro','Botta','Montero','Delantero',45,1,2,0,10),(274,'Jose','Calero','Sierra','Delantero',66,2,3,1,10),(275,'Daniel','Hernandez','Govea','Delantero',32,7,2,0,10),(276,'Rodrigo','Lozano','Bahena','Delantero',88,2,1,0,10),(277,'Gerardo','Nahuelpan','Osten','Delantero',23,3,0,0,10),(278,'Fernando','Ochoa','Chavez','Delantero',43,8,2,0,10),(279,'Manuel','Perez','Ruiz','Delantero',11,1,0,0,10),(280,'Gilbert','Pizarro','Thomas','Delantero',19,0,4,0,10),(281,'Gustavo','Ramirez','Rojas','Delantero',87,4,0,0,10),(282,'Jonathan','Matias','Urretaviscaya','Delantero',65,5,1,0,10),(283,'Fernandez','Garcia','Aaron','Portero',21,0,0,0,11),(284,'Ignacio','Guzman','Nahuel','Portero',1,2,0,0,11),(285,'Palos','Reyes','Enrique','Portero',22,0,0,0,11),(286,'Alvarado','Garcia','Victor','Defensa',92,0,0,0,11),(287,'Ayala','Castro','Hugo','Defensa',4,0,0,0,11),(288,'Briseno','Vazquez','Antonio','Defensa',13,0,0,0,11),(289,'Estrada','Manjarrez','Jorge','Defensa',14,0,0,0,11),(290,'Garcia','Manriquez','Jose','Defensa',28,0,0,0,11),(291,'Jimenez','Nanez','Israel','Defensa',2,3,0,0,11),(292,'Vendrechovski','Junior','Anselmo','Defensa',3,1,0,1,11),(293,'Rivas','null','Jose','Defensa',24,0,0,0,11),(294,'Torres','Nilo','Jorge','Defensa',6,2,0,0,11),(295,'Alvarez','null','Damian','Medio',11,0,0,1,11),(296,'Aquino','Carmona','Javier','Medio',20,4,0,2,11),(297,'Castillo','Martinez','Luis','Medio',95,0,0,0,11),(298,'Duenas','Manzo','Jesus','Medio',29,1,0,1,11),(299,'Espericueta','Escamilla','Jorge','Medio',34,0,0,0,11),(300,'Garcia','Martinez','Ramon','Medio',29,0,0,0,11),(301,'Luna','Martinez','Uvaldo','Medio',98,0,0,0,11),(302,'Pizarro','Demestri','Guido','Medio',19,4,0,0,11),(303,'Torres','Mezzell','Jose','Medio',18,0,0,0,11),(304,'Vela','Flores','Orlando','Medio',96,0,0,0,11),(305,'Viniegra','Garcia','Manuel','Medio',15,0,0,0,11),(306,'Zelarrayan','null','Lucas','Medio',8,0,0,1,11),(307,'Chavez','Soto','Ricardo','Delantero',90,0,0,0,11),(308,'Cruz','Ontiveros','Luis','Delantero',30,0,0,0,11),(309,'Damm','Rascon','Jurgen','Delantero',25,4,0,0,11),(310,'Fernandez','Acosta','Fernando','Delantero',5,0,0,1,11),(311,'Gignac','null','Andre Pierre','Delantero',10,2,0,8,11),(312,'Mancilla','Garces','Hector','Delantero',17,0,0,0,11),(313,'Sobisdo','Nascimento','Rafael','Delantero',9,1,1,2,11),(314,'Orozco','null','Jonathan Emmanuel','Portero',1,0,0,10,12),(315,'Cardenas','null','Alberto','Portero',22,0,0,1,12),(316,'Resendez','null','Edson','Portero',28,0,0,0,12),(317,'de Dios ','Ibarra','Juan','Portero',23,0,0,0,12),(318,'Basanta','null','Jose Maria','Defensa',30,2,0,0,12),(319,'Castillo','null','Edgar Eduardo','Defensa',15,2,0,1,12),(320,'Montes','null','Cesar Jasib','Defensa',28,2,0,0,12),(321,'Osorio','null','Ricardo','Defensa',4,1,0,0,12),(322,'Juarez','null','Efrain','Defensa',6,1,0,1,12),(323,'Mier','null','Hiram','Defensa',21,0,0,0,12),(324,'Herrera','null','Miguel Angel','Defensa',34,2,1,0,12),(325,'Lopez','null','Luis Alberto','Defensa',19,0,0,0,12),(326,'Portales','null','Juan Antonio','Defensa',25,0,0,0,12),(327,'Hernandez','null','Bernardo','Defensa',14,0,0,0,12),(328,'Sanchez','null','Carlos Andres','Medio',13,2,0,4,12),(329,'Cardona','null','Edwin Andres','Medio',10,3,0,4,12),(330,'Gargano','null','Walter','Medio',5,3,0,0,12),(331,'Ayov','null','Walter','Medio',33,2,1,0,12),(332,'Zavala','null','Jesus Eduardo','Medio',17,3,0,0,12),(333,'Ramirez','null','Saul','Medio',16,1,0,0,12),(334,'Cardozo','null','Neri','Medio',18,0,0,0,12),(335,'Barrera','null','Pablo','Medio',11,0,0,0,12),(336,'Perez','null','Luis Ernesto','Medio',27,0,0,0,12),(337,'Dominguez','null','Marcelo Gracia','Medio',24,0,0,0,12),(338,'Talancon','null','Mauricio','Medio',29,0,0,0,12),(339,'Pabon','null','Dorlan','Delantero',8,1,0,3,12),(340,'Funes','Mori','Rogelio','Delantero',7,5,0,5,12),(341,'de Nigris','null','Aldo','Delantero',9,1,0,1,12),(342,'Gonzalez','null','Julio','Delantero',97,0,0,0,12),(343,'Rivera','null','Santiago','Delantero',20,0,0,0,12),(344,'Marchesin','null','Agustin Federico','Portero',1,2,0,12,13),(345,'Gonzalez','null','Julio Jose','Portero',32,0,0,0,13),(346,'Izquierdoz','null','Carlos','Defensa',24,4,0,0,13),(347,'Araujo','null','Nestor Alejandro','Defensa',14,1,0,0,13),(348,'Villafana','null','Jorge Flores','Defensa',19,0,0,0,13),(349,'Abella','null','Jose Javier','Defensa',2,3,1,0,13),(350,'Ibanez','null','Cesar Alberto','Defensa',5,1,0,0,13),(447,'Fuentes','Vargas','Luis Fernando','Defensa',5,0,0,0,17),(448,'Sosa','null','Victor Ismael','Delantero',18,1,0,3,17),(449,'Palacios','Redorta','Miguel Alejandro','Portero',1,0,0,0,17),(450,'Alcoba','Rebollo','Gerardo','Defensa',3,1,0,0,17),(451,'Cortes','Granados','Javier','Medio',7,0,0,0,17),(452,'Alatorre','Maldonado','Marcelo Guadalupe','Defensa',16,1,0,0,17),(453,'Herrera','Aguirre','Victor Ismael','Delantero',18,1,0,3,17),(454,'Castro','Flores','Alejandro','Medio',21,1,0,0,17),(455,'Britos','Cardoso','Matias','Delantero',20,2,0,2,17),(456,'Quinones','null','Luis Enrique','Medio',24,2,0,2,17),(457,'Ruiz','Vazquez','Hibert Alberto','Defensa',17,0,0,0,17),(458,'Martinez','Tenorio','Fidel Francisco','Medio ',11,3,0,1,17),(459,'Luduena','null','Daniel Emanuel','Delantero ',10,0,0,1,17),(460,'Lopez','Farina','Dante Rafael','Delantero',9,0,0,0,17),(461,'Cabrera','Pujol','David','Medio',8,0,0,0,17),(462,'Van Rankin','Galland','Josecarlos','Defensa',2,0,0,0,17),(463,'Vidangossy','Rebolledo','Mathias Leonardo','Delantero',19,0,0,0,17),(464,'Saldivar','Medina','Alfredo','Portero',13,0,0,0,17),(465,'Meza','Palma','Francisco Javier','Defensa',28,0,0,0,17),(466,'Corona','null','Jose de Jesus','Portero',1,3,0,9,18),(467,'Allison','null','Guillermo','Portero',12,0,0,6,18),(468,'Pelaez','null','Alejandro','Portero',20,0,0,0,18),(469,'Dominguez','null','Julio Cesar','Defensa',4,2,0,1,18),(470,'Santos','null','Fabio','Defensa',5,0,0,1,18),(471,'Rodriguez','null','Francisco Javier','Defensa',3,6,2,0,18),(472,'Pinto','null','Fausto','Defensa',2,1,0,0,18),(473,'Sancho','null','Juan Garcia','Defensa',25,2,1,0,18),(474,'Madrid','null','Manuel','Defensa',13,0,0,0,18),(475,'Chavez','null','Rogelio','Defensa',16,0,0,0,18),(476,'Borjas','null','Silvio','Defensa',17,0,0,0,18),(477,'Mendoza','null','Omar Israel','Medio',28,5,0,1,18),(478,'Baca','null','Rafael','Medio',22,1,0,0,18),(479,'Ramirez','null','Aldo Leao','Medio',14,1,0,1,18),(480,'Rojas','null','Ariel','Medio',18,2,0,1,18),(481,'Vazquez','null','Victor','Medio',7,0,0,1,18),(482,'Torrado','null','Gerardo','Medio',6,0,0,0,18),(483,'Zuniga','null','Victor','Medio',29,0,0,0,18),(484,'Ruiz','null','Richard','Medio',23,0,0,0,18),(485,'Crosas','null','Marc','Medio',8,0,0,0,18),(486,'Guerron','null','Joffre David','Delantero',9,2,0,1,18),(487,'Benitez','null','Jorge Daniel','Delantero',27,3,1,6,18),(488,'Gimenez','null','Christian','Delantero',10,0,0,4,18),(489,'Rojas','null','Joao','Delantero',11,1,0,2,18),(490,'Vuoso','null','Vicente Matias','Delantero',30,0,0,1,18),(491,'Gonzalez','null','Juan','Delantero',26,0,0,0,18),(492,'Rivera','Montes','Fabiano','Delantero',13,3,1,4,11),(493,'Rivera','Montes','Fabiano','Delantero',13,3,1,4,11);
/*!40000 ALTER TABLE `jugador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partido`
--

DROP TABLE IF EXISTS `partido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partido` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `equipo_local` varchar(20) NOT NULL,
  `equipo_visitante` varchar(20) NOT NULL,
  `goles_local` tinyint(2) NOT NULL,
  `goles_visitante` tinyint(2) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `id_equipo_local` tinyint(2) NOT NULL,
  `id_equipo_visitante` tinyint(2) NOT NULL,
  `jornada` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `enlace` (`id_equipo_local`),
  KEY `enlace2` (`id_equipo_visitante`),
  CONSTRAINT `enlace` FOREIGN KEY (`id_equipo_local`) REFERENCES `equipo` (`id`),
  CONSTRAINT `enlace2` FOREIGN KEY (`id_equipo_visitante`) REFERENCES `equipo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partido`
--

LOCK TABLES `partido` WRITE;
/*!40000 ALTER TABLE `partido` DISABLE KEYS */;
INSERT INTO `partido` VALUES (1,'Guadalajara','Veracruz',2,2,'2016-01-10','17:00:00',1,7,1),(2,'Toluca','Uanl',1,0,'2016-01-10','12:00:00',6,11,1),(3,'Chiapas','Dorados',1,0,'2016-01-09','21:00:00',8,15,1),(4,'Morelia','Cruz Azul',2,2,'2016-01-09','20:30:00',4,18,1),(5,'Leon','Santos Laguna',2,0,'2016-01-09','20:06:00',3,13,1),(6,'Monterrey','Unam',1,0,'2016-01-09','19:00:00',12,17,1),(7,'America','Puebla',0,0,'2016-01-09','17:00:00',16,9,1),(8,'Tijuana','Pachuca',1,1,'2016-01-08','21:30:00',14,10,1),(9,'Queretaro','Atlas',1,3,'2016-01-08','19:30:00',5,2,1),(10,'Puebla','Monterrey',1,3,'2016-01-17','17:00:00',9,12,2),(11,'Unam','Toluca',3,2,'2016-01-17','12:00:00',17,6,2),(12,'Dorados','Tijuana',0,1,'2016-01-16','21:00:00',15,14,2),(13,'Atlas','America',0,3,'2016-01-16','20:30:00',2,16,2),(14,'Pachuca','Queretaro',1,0,'2016-01-16','20:06:00',10,5,2),(15,'Uanl','Morelia',2,0,'2016-01-16','19:00:00',11,4,2),(16,'Cruz Azul','Guadalajara',1,1,'2016-01-16','17:00:00',18,1,2),(17,'Santos Lagunas','Chiapas',1,0,'2016-01-15','21:30:00',13,8,2),(18,'Veracruz','Leon',1,3,'2016-01-15','19:30:00',7,3,2),(19,'Guadalajara','Uanl',2,2,'2016-01-24','17:00:00',1,11,3),(20,'Unam','Puebla',0,1,'2016-01-24','12:00:00',17,9,3),(21,'Chiapas','Veracruz',1,1,'2016-01-23','21:00:00',8,7,3),(22,'Morelia','Toluca',1,1,'2016-01-23','20:30:00',4,6,3),(23,'Leon','Cruz Azul',3,2,'2016-01-23','20:06:00',3,18,3),(24,'Monterrey','Atlas',1,0,'2016-01-23','19:00:00',12,2,3),(25,'America','Pachuca',1,4,'2016-01-23','17:00:00',16,10,3),(26,'Tijuana','Santos Laguna',1,3,'2016-01-22','21:30:00',14,13,3),(27,'Queretaro','Dorados',3,0,'2016-01-22','19:30:00',5,15,3),(28,'Toluca','Puebla',1,1,'2016-01-31','12:00:00',6,9,4),(29,'Dorados','America',0,3,'2016-01-30','21:00:00',15,16,4),(30,'Atlas','Unam',1,1,'2016-01-30','20:30:00',2,17,4),(31,'Pachuca','Monterrey',3,1,'2016-01-30','20:06:00',10,12,4),(32,'Uanl','Leon',3,1,'2016-01-30','19:00:00',11,3,4),(33,'Morelia','Guadalajara',2,0,'2016-01-30','18:30:00',4,1,4),(34,'Cruz Azul','Chiapas',2,1,'2016-01-30','17:00:00',18,8,4),(35,'Santos Laguna','Queretaro',2,0,'2016-01-29','21:30:00',13,5,4),(36,'Veracruz','Tijuana',2,2,'2016-01-29','21:30:00',7,14,4),(37,'Unam','Pachuca',1,1,'2016-02-07','12:00:00',17,10,5),(38,'Guadalajara','Toluca',1,1,'2016-02-06','21:00:00',1,6,5),(39,'Leon','Morelia',1,2,'2016-02-06','20:06:00',3,4,5),(40,'Monterrey','Dorados',3,0,'2016-02-06','19:00:00',12,15,5),(41,'Puebla','Atlas',4,1,'2016-02-06','19:00:00',9,2,5),(42,'America','Santos Laguna',2,0,'2016-02-06','17:00:00',16,13,5),(43,'Tijuana','Cruz Azul',1,1,'2016-02-05','21:30:00',14,18,5),(44,'Chiapas','Uanl',1,3,'2016-02-05','21:00:00',8,11,5),(45,'Queretaro','Veracruz',2,1,'2016-02-05','19:30:00',5,7,5),(46,'Guadalajara','Unam',13,20,'3916-05-28','04:56:10',4,11,3),(47,'Guadalajara','Unam',13,20,'3916-05-28','04:56:10',4,11,3);
/*!40000 ALTER TABLE `partido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `torneo`
--

DROP TABLE IF EXISTS `torneo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `torneo` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  `temporada` varchar(20) NOT NULL,
  `inicio` date NOT NULL,
  `fin` date NOT NULL,
  `campeon` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `torneo`
--

LOCK TABLES `torneo` WRITE;
/*!40000 ALTER TABLE `torneo` DISABLE KEYS */;
INSERT INTO `torneo` VALUES (1,'Liga MX','2015-2016','0000-00-00','0000-00-00','Tigres'),(5,'LigaBBA','2015-2016','3916-06-11','3916-05-23','Indios'),(6,'Liga mexico','2015-2016','2016-05-14','2016-05-14','Guadalajara'),(7,'Liga mexico','2015-2016','2016-05-14','2018-05-14','Guadalajara');
/*!40000 ALTER TABLE `torneo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `usuario` varchar(15) NOT NULL DEFAULT '',
  `pass` varchar(10) NOT NULL,
  `tipo` varchar(10) NOT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES ('admin','1234','admin'),('secretaria','1234','secretaria');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-18  4:31:35
