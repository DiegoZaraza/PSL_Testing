CREATE DATABASE  IF NOT EXISTS `liga` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `liga`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: liga
-- ------------------------------------------------------
-- Server version	5.6.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equipo`
--

DROP TABLE IF EXISTS `equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipo` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  `mascota` varchar(20) DEFAULT NULL,
  `estadio` varchar(20) NOT NULL,
  `ciudad` varchar(20) NOT NULL,
  `partidos_jugados` tinyint(2) DEFAULT NULL,
  `partidos_ganados` tinyint(2) NOT NULL,
  `partidos_empatados` tinyint(2) NOT NULL,
  `partidos_perdidos` tinyint(2) NOT NULL,
  `goles_favor` tinyint(2) NOT NULL,
  `goles_encontra` tinyint(2) NOT NULL,
  `diferencia_goles` tinyint(2) NOT NULL,
  `puntos` tinyint(2) NOT NULL,
  `liga` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_liga` (`liga`),
  CONSTRAINT `fk_liga` FOREIGN KEY (`liga`) REFERENCES `equipo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo`
--

LOCK TABLES `equipo` WRITE;
/*!40000 ALTER TABLE `equipo` DISABLE KEYS */;
INSERT INTO `equipo` VALUES (1,'Guadalajara','Chiva','Omnilife','Zapopan',10,4,6,3,21,14,7,18,1),(2,'Atlas Guadalajara','Zorro','Estadio Jalisco','Guadalajara',10,1,6,3,14,24,-10,9,1),(3,'Leon','Leon','Now Camp','Leon',10,6,1,3,23,17,6,22,1),(4,'Morelia','Monarca','Morelos','Michoacan',10,2,4,3,19,20,-1,19,1),(5,'Queretaro','Gallo','Correjidora','Queretaro',10,2,2,6,15,19,-4,13,1),(6,'Toluca','Diablo','Nemesio Diez','Toluca',10,2,4,4,13,16,-3,13,1),(7,'Veracruz','Tiburon','Pirata Fuente','Veracruz',10,1,6,3,13,27,-14,10,1),(8,'Chiapas','Jaguar','Manuel Reyna','Tuxtla Gutierrez',10,3,2,4,13,24,-11,12,1),(9,'Puebla','Camote','Cuauhtemoc','Puebla',10,3,5,2,15,20,-5,15,1),(10,'Pachuca','Pachus','Hidalgo','Pachuca',10,5,3,2,28,13,15,25,1),(11,'Tigres','Tigre','Universitario','San Nicolas',10,4,3,3,20,15,5,17,1),(12,'Monterrey','Monty','BBVA Bancomer','Monterrey',10,8,0,2,29,15,14,30,1),(13,'Santos','Apache','Corona','Torreon',10,5,2,3,17,15,2,21,1),(14,'Tijuana','Xoloitzcuintle','Caliente','Tijuana',10,3,6,1,15,21,-6,16,1),(15,'Dorados','Dorado','Banorte','Culiacan',10,1,1,8,14,24,-10,11,1),(16,'America','Aguila','Azteca','Ciudad de Mexico',10,5,3,2,30,16,14,27,1),(17,'Unam','Puma','Olimpico','Ciudad de Mexico',10,2,6,2,16,19,-3,15,1),(18,'Cruz azul','Conejo','Azul','Ciudad de Mexico',10,3,6,1,22,18,4,19,1),(19,'Indios','Indio','Los Altos','Monterrey',20,17,2,1,11,8,3,22,1),(20,'Indios','Indio','Los Altos','Monterrey',20,17,2,1,11,8,3,22,1),(21,'Indios','Indio','Los Altos','Monterrey',20,17,2,1,11,8,3,22,1);
/*!40000 ALTER TABLE `equipo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-18  4:34:37
