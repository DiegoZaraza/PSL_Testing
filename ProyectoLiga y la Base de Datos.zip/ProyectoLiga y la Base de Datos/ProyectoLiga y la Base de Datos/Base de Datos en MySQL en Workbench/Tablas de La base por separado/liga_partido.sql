CREATE DATABASE  IF NOT EXISTS `liga` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `liga`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: liga
-- ------------------------------------------------------
-- Server version	5.6.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `partido`
--

DROP TABLE IF EXISTS `partido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partido` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `equipo_local` varchar(20) NOT NULL,
  `equipo_visitante` varchar(20) NOT NULL,
  `goles_local` tinyint(2) NOT NULL,
  `goles_visitante` tinyint(2) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `id_equipo_local` tinyint(2) NOT NULL,
  `id_equipo_visitante` tinyint(2) NOT NULL,
  `jornada` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `enlace` (`id_equipo_local`),
  KEY `enlace2` (`id_equipo_visitante`),
  CONSTRAINT `enlace` FOREIGN KEY (`id_equipo_local`) REFERENCES `equipo` (`id`),
  CONSTRAINT `enlace2` FOREIGN KEY (`id_equipo_visitante`) REFERENCES `equipo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partido`
--

LOCK TABLES `partido` WRITE;
/*!40000 ALTER TABLE `partido` DISABLE KEYS */;
INSERT INTO `partido` VALUES (1,'Guadalajara','Veracruz',2,2,'2016-01-10','17:00:00',1,7,1),(2,'Toluca','Uanl',1,0,'2016-01-10','12:00:00',6,11,1),(3,'Chiapas','Dorados',1,0,'2016-01-09','21:00:00',8,15,1),(4,'Morelia','Cruz Azul',2,2,'2016-01-09','20:30:00',4,18,1),(5,'Leon','Santos Laguna',2,0,'2016-01-09','20:06:00',3,13,1),(6,'Monterrey','Unam',1,0,'2016-01-09','19:00:00',12,17,1),(7,'America','Puebla',0,0,'2016-01-09','17:00:00',16,9,1),(8,'Tijuana','Pachuca',1,1,'2016-01-08','21:30:00',14,10,1),(9,'Queretaro','Atlas',1,3,'2016-01-08','19:30:00',5,2,1),(10,'Puebla','Monterrey',1,3,'2016-01-17','17:00:00',9,12,2),(11,'Unam','Toluca',3,2,'2016-01-17','12:00:00',17,6,2),(12,'Dorados','Tijuana',0,1,'2016-01-16','21:00:00',15,14,2),(13,'Atlas','America',0,3,'2016-01-16','20:30:00',2,16,2),(14,'Pachuca','Queretaro',1,0,'2016-01-16','20:06:00',10,5,2),(15,'Uanl','Morelia',2,0,'2016-01-16','19:00:00',11,4,2),(16,'Cruz Azul','Guadalajara',1,1,'2016-01-16','17:00:00',18,1,2),(17,'Santos Lagunas','Chiapas',1,0,'2016-01-15','21:30:00',13,8,2),(18,'Veracruz','Leon',1,3,'2016-01-15','19:30:00',7,3,2),(19,'Guadalajara','Uanl',2,2,'2016-01-24','17:00:00',1,11,3),(20,'Unam','Puebla',0,1,'2016-01-24','12:00:00',17,9,3),(21,'Chiapas','Veracruz',1,1,'2016-01-23','21:00:00',8,7,3),(22,'Morelia','Toluca',1,1,'2016-01-23','20:30:00',4,6,3),(23,'Leon','Cruz Azul',3,2,'2016-01-23','20:06:00',3,18,3),(24,'Monterrey','Atlas',1,0,'2016-01-23','19:00:00',12,2,3),(25,'America','Pachuca',1,4,'2016-01-23','17:00:00',16,10,3),(26,'Tijuana','Santos Laguna',1,3,'2016-01-22','21:30:00',14,13,3),(27,'Queretaro','Dorados',3,0,'2016-01-22','19:30:00',5,15,3),(28,'Toluca','Puebla',1,1,'2016-01-31','12:00:00',6,9,4),(29,'Dorados','America',0,3,'2016-01-30','21:00:00',15,16,4),(30,'Atlas','Unam',1,1,'2016-01-30','20:30:00',2,17,4),(31,'Pachuca','Monterrey',3,1,'2016-01-30','20:06:00',10,12,4),(32,'Uanl','Leon',3,1,'2016-01-30','19:00:00',11,3,4),(33,'Morelia','Guadalajara',2,0,'2016-01-30','18:30:00',4,1,4),(34,'Cruz Azul','Chiapas',2,1,'2016-01-30','17:00:00',18,8,4),(35,'Santos Laguna','Queretaro',2,0,'2016-01-29','21:30:00',13,5,4),(36,'Veracruz','Tijuana',2,2,'2016-01-29','21:30:00',7,14,4),(37,'Unam','Pachuca',1,1,'2016-02-07','12:00:00',17,10,5),(38,'Guadalajara','Toluca',1,1,'2016-02-06','21:00:00',1,6,5),(39,'Leon','Morelia',1,2,'2016-02-06','20:06:00',3,4,5),(40,'Monterrey','Dorados',3,0,'2016-02-06','19:00:00',12,15,5),(41,'Puebla','Atlas',4,1,'2016-02-06','19:00:00',9,2,5),(42,'America','Santos Laguna',2,0,'2016-02-06','17:00:00',16,13,5),(43,'Tijuana','Cruz Azul',1,1,'2016-02-05','21:30:00',14,18,5),(44,'Chiapas','Uanl',1,3,'2016-02-05','21:00:00',8,11,5),(45,'Queretaro','Veracruz',2,1,'2016-02-05','19:30:00',5,7,5),(46,'Guadalajara','Unam',13,20,'3916-05-28','04:56:10',4,11,3),(47,'Guadalajara','Unam',13,20,'3916-05-28','04:56:10',4,11,3);
/*!40000 ALTER TABLE `partido` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-18  4:34:36
