
package proyectoliga.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.AlineacionDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class AlineacionDAO {
    
    private static final String SQL_INSERT
            = "INSERT INTO alineacion ("
            + "id_partido, id_jugador, inicio, fin, puesto"
            + ") VALUES (?, ?, ?, ?, ?)";
    private static final String SQL_SELECT
            = "SELECT id_partido, id_jugador, inicio, fin, puesto "
            + "  FROM alineacion where id= ?";
    private static final String SQL_SELECT_All
            = "SELECT id_partido, id_jugador, inicio, fin, puesto, id "
            + "FROM alineacion";
    private static final String SQL_UPDATE
            = "UPDATE alineacion SET "
            + "id_partido = ?, id_jugador = ?, inicio = ?, fin = ?, puesto = ? "
            + " WHERE "
            + "id = ? ";
    private static final String SQL_DELETE
            = "DELETE FROM alineacion "
            + "WHERE id = ?";

    private DBConnection conexion;

    public AlineacionDAO(DBConnection conexion) {
        this.conexion = conexion;
    }

    public boolean insertar(AlineacionDTO alineacion) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_INSERT);
        pstmt.setByte(1, alineacion.getId_partido());
        pstmt.setByte(2, alineacion.getId_jugador());
        pstmt.setDate(3, new java.sql.Date(alineacion.getInicio().getTime()));
        pstmt.setDate(4, new java.sql.Date(alineacion.getFin().getTime()));
        pstmt.setString(5, alineacion.getPuesto());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        pstmt.close();
        return status;
    }

    public boolean eliminar(AlineacionDTO alineacion) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_DELETE);
        pstmt.setByte(1, alineacion.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public boolean actualizar(AlineacionDTO alineacion) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_UPDATE);
        pstmt.setByte(1, alineacion.getId_partido());
        pstmt.setByte(2, alineacion.getId_jugador());
        pstmt.setDate(3, new java.sql.Date(alineacion.getInicio().getTime()));
        pstmt.setDate(4, new java.sql.Date(alineacion.getFin().getTime()));
        pstmt.setString(5, alineacion.getPuesto());
        pstmt.setByte(6, alineacion.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public AlineacionDTO buscar(AlineacionDTO alineacion) throws SQLException, Exception {
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT);
        ResultSet result = null;
        pstmt.setByte(1, alineacion.getId());
        result = pstmt.executeQuery();
        if (result.next()) {
            alineacion.setId_partido(result.getByte(1));
            alineacion.setId_jugador(result.getByte(2));
            alineacion.setInicio(result.getTime(3));
            alineacion.setFin(result.getTime(4));
            alineacion.setPuesto(result.getString(5));
            alineacion.setId(result.getByte(6));
        } else {
            alineacion = null;
        }
        return alineacion; 
    }

    public List<AlineacionDTO> listar() throws SQLException, Exception {
        List<AlineacionDTO> alineaciones = new LinkedList<AlineacionDTO>();
        ResultSet result = null;
        AlineacionDTO alineacion;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT_All);
        result = pstmt.executeQuery();
        while (result.next()) {
            alineacion = new AlineacionDTO();
            alineacion.setId_partido(result.getByte(1));
            alineacion.setId_jugador(result.getByte(2));
            alineacion.setInicio(result.getTime(3));
            alineacion.setFin(result.getTime(4));
            alineacion.setPuesto(result.getString(5));
            alineacion.setId(result.getByte(6));
            alineaciones.add(alineacion);
        }
        return alineaciones;
    }
}

