package proyectoliga.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import proyectoliga.DBC.DBConnection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import proyectoliga.DTO.TorneoDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class TorneoDAO {

    private static final String SQL_INSERT
            = "INSERT INTO torneo ("
            + "nombre, temporada, inicio, fin, campeon "
            + ") VALUES (?, ?, ?, ?, ?)";
    private static final String SQL_SELECT
            = "SELECT nombre, temporada, inicio, fin, campeon "
            + "  FROM torneo where id= ?";
    private static final String SQL_SELECT_All
            = "SELECT nombre, temporada, inicio, fin, campeon, id "
            + "FROM torneo";
    private static final String SQL_UPDATE
            = "UPDATE torneo SET "
            + "nombre = ?, temporada = ?, inicio = ?, fin = ?, campeon = ? "
            + " WHERE "
            + "id = ? ";
    private static final String SQL_DELETE
            = "DELETE FROM torneo "
            + "WHERE id = ?";

    private DBConnection conexion;

    public TorneoDAO(DBConnection conexion) {
        this.conexion = conexion;
    }

   

    public boolean insertar(TorneoDTO torneo) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_INSERT);
        pstmt.setString(1, torneo.getNombre());
        pstmt.setString(2, torneo.getTemporada());
        pstmt.setDate(3, new java.sql.Date(torneo.getInicio().getTime()));
        pstmt.setDate(4, new java.sql.Date(torneo.getFin().getTime()));
        pstmt.setString(5, torneo.getCampeon());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        pstmt.close();
        return status;
    }

    public boolean eliminar(TorneoDTO torneo) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_DELETE);
        pstmt.setByte(1, torneo.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public boolean actualizar(TorneoDTO torneo) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_UPDATE);
        pstmt.setString(1, torneo.getNombre());
        pstmt.setString(2, torneo.getTemporada());
        pstmt.setDate(3, new java.sql.Date(torneo.getInicio().getTime()));
        pstmt.setDate(4, new java.sql.Date(torneo.getFin().getTime()));
        pstmt.setString(5, torneo.getCampeon());
        pstmt.setByte(6, torneo.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public TorneoDTO buscar(TorneoDTO torneo) throws SQLException, Exception {
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT);
        ResultSet result = null;
        pstmt.setByte(1, torneo.getId());
        result = pstmt.executeQuery();
        if (result.next()) {
            torneo.setNombre(result.getString(1));
            torneo.setTemporada(result.getString(2));
            torneo.setInicio(result.getDate(3));
            torneo.setFin(result.getDate(4));
            torneo.setCampeon(result.getString(5));
            torneo.setId(result.getByte(6));
        } else {
            torneo = null;
        }
        return torneo; 
    }

    public List<TorneoDTO> listar() throws SQLException, Exception {
        List<TorneoDTO> torneos = new LinkedList<TorneoDTO>();
        ResultSet result = null;
        TorneoDTO torneo;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT_All);
        result = pstmt.executeQuery();
        while (result.next()) {
            torneo = new TorneoDTO();
            torneo.setNombre(result.getString(1));
            torneo.setTemporada(result.getString(2));
            torneo.setInicio(result.getDate(3));
            torneo.setFin(result.getDate(4));
            torneo.setCampeon(result.getString(5));
            torneo.setId(result.getByte(6));
            torneos.add(torneo);
        }
        return torneos;
    }
}
