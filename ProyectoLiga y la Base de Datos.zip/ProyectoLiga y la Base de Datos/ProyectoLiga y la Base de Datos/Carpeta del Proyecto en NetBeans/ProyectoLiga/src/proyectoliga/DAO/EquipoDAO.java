/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoliga.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.EquipoDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class EquipoDAO {
    private static final String SQL_INSERT
            = "INSERT INTO equipo ("
            + "nombre, mascota, estadio, ciudad, partidos_jugados, partidos_ganados, partidos_empatados, partidos_perdidos, goles_favor, goles_encontra, diferencia_goles, puntos, liga"
            + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_SELECT
            = "SELECT nombre, mascota, estadio, ciudad, partidos_jugados, partidos_ganados, partidos_empatados, partidos_perdidos, goles_favor, goles_encontra, diferencia_goles, puntos, liga "
            + "  FROM equipo where id= ?";
    private static final String SQL_SELECT_All
            = "SELECT nombre, mascota, estadio, ciudad, partidos_jugados, partidos_ganados, partidos_empatados, partidos_perdidos, goles_favor, goles_encontra, diferencia_goles, puntos, liga, id "
            + "FROM equipo";
    private static final String SQL_UPDATE
            = "UPDATE equipo SET "
            + "nombre = ?, mascota = ?, estadio = ?, ciudad = ?, partidos_jugados = ?, partidos_ganados= ?, partidos_empatados=?, partidos_perdidos = ?, goles_favor = ?, goles_encontra = ?, diferencia_goles = ?, puntos = ?, liga = ? "
            + " WHERE "
            + "id = ? ";
    private static final String SQL_DELETE
            = "DELETE FROM equipo "
            + "WHERE id = ?";

    private DBConnection conexion;

    public EquipoDAO(DBConnection conexion) {
        this.conexion = conexion;
    }

    public boolean insertar(EquipoDTO equipo) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_INSERT);
        pstmt.setString(1, equipo.getNombre());
        pstmt.setString(2, equipo.getMascota());
        pstmt.setString(3, equipo.getEstadio());
        pstmt.setString(4, equipo.getCiudad());
        pstmt.setByte(5, equipo.getPartidos_jugados());
        pstmt.setByte(6, equipo.getPartidos_ganados());
        pstmt.setByte(7, equipo.getPartidos_empatados());
        pstmt.setByte(8, equipo.getPartidos_perdidos());
        pstmt.setByte(9, equipo.getGoles_favor());
        pstmt.setByte(10, equipo.getGoles_encontra());
        pstmt.setByte(11, equipo.getDiferencia_goles());
        pstmt.setByte(12, equipo.getPuntos());
        pstmt.setByte(13, equipo.getLiga());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        pstmt.close();
        return status;
    }

    public boolean eliminar(EquipoDTO equipo) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_DELETE);
        pstmt.setByte(1, equipo.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public boolean actualizar(EquipoDTO equipo) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_UPDATE);
        pstmt.setString(1, equipo.getNombre());
        pstmt.setString(2, equipo.getMascota());
        pstmt.setString(3, equipo.getEstadio());
        pstmt.setString(4, equipo.getCiudad());
        pstmt.setByte(5, equipo.getPartidos_jugados());
        pstmt.setByte(6, equipo.getPartidos_ganados());
        pstmt.setByte(7, equipo.getPartidos_empatados());
        pstmt.setByte(8, equipo.getPartidos_perdidos());
        pstmt.setByte(9, equipo.getGoles_favor());
        pstmt.setByte(10, equipo.getGoles_encontra());
        pstmt.setByte(11, equipo.getDiferencia_goles());
        pstmt.setByte(12, equipo.getPuntos());
        pstmt.setByte(13, equipo.getLiga());
        pstmt.setByte(14, equipo.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public EquipoDTO buscar(EquipoDTO equipo) throws SQLException, Exception {
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT);
        ResultSet result = null;
        pstmt.setByte(1, equipo.getId());
        result = pstmt.executeQuery();
        if (result.next()) {
            equipo.setNombre(result.getString(1));
            equipo.setMascota(result.getString(2));
            equipo.setEstadio(result.getString(3));
            equipo.setCiudad(result.getString(4));
            equipo.setPartidos_jugados(result.getByte(5));
            equipo.setPartidos_ganados(result.getByte(6));
            equipo.setPartidos_empatados(result.getByte(7));
            equipo.setPartidos_perdidos(result.getByte(8));
            equipo.setGoles_favor(result.getByte(9));
            equipo.setGoles_encontra(result.getByte(10));
            equipo.setDiferencia_goles(result.getByte(11));
            equipo.setPuntos(result.getByte(12));
            equipo.setLiga(result.getByte(13));
            equipo.setId(result.getByte(14));
        } else {
            equipo = null;
        }
        return equipo; 
    }

    public List<EquipoDTO> listar() throws SQLException, Exception {
        List<EquipoDTO> equipos = new LinkedList<EquipoDTO>();
        ResultSet result = null;
        EquipoDTO equipo;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT_All);
        result = pstmt.executeQuery();
        while (result.next()) {
            equipo = new EquipoDTO();
            equipo.setNombre(result.getString(1));
            equipo.setMascota(result.getString(2));
            equipo.setEstadio(result.getString(3));
            equipo.setCiudad(result.getString(4));
            equipo.setPartidos_jugados(result.getByte(5));
            equipo.setPartidos_ganados(result.getByte(6));
            equipo.setPartidos_empatados(result.getByte(7));
            equipo.setPartidos_perdidos(result.getByte(8));
            equipo.setGoles_favor(result.getByte(9));
            equipo.setGoles_encontra(result.getByte(10));
            equipo.setDiferencia_goles(result.getByte(11));
            equipo.setPuntos(result.getByte(12));
            equipo.setLiga(result.getByte(13));
            equipo.setId(result.getByte(14));
            equipos.add(equipo);
        }
        return equipos;
    }
}
