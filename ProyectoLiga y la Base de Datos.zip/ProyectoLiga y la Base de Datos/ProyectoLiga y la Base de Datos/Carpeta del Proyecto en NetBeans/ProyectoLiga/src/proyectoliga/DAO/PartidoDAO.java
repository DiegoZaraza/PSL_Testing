
package proyectoliga.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.PartidoDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class PartidoDAO {

    private static final String SQL_INSERT
            = "INSERT INTO partido ("
            + "equipo_local, equipo_visitante, goles_local, goles_visitante, fecha, hora, id_equipo_local, id_equipo_visitante, jornada"
            + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_SELECT
            = "SELECT equipo_local, equipo_visitante, goles_local, goles_visitante, fecha, hora, id_equipo_local, id_equipo_visitante, jornada "
            + "  FROM partido where id= ?";
    private static final String SQL_SELECT_All
            = "SELECT equipo_local, equipo_visitante, goles_local, goles_visitante, fecha, hora, id_equipo_local, id_equipo_visitante, jornada, id "
            + "FROM partido";
    private static final String SQL_UPDATE
            = "UPDATE partido SET "
            + "equipo_local = ?, equipo_visitante = ?, goles_local = ?, goles_visitante = ?, fecha = ?, hora = ?, id_equipo_local = ?, id_equipo_visitante = ?, jornada = ? "
            + " WHERE "
            + "id = ? ";
    private static final String SQL_DELETE
            = "DELETE FROM partido "
            + "WHERE id = ?";

    private DBConnection conexion;

    public PartidoDAO(DBConnection conexion) {
        this.conexion = conexion;
    }

    public boolean insertar(PartidoDTO partido) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_INSERT);
        pstmt.setString(1, partido.getEquipo_local());
        pstmt.setString(2, partido.getEquipo_visitante());
        pstmt.setByte(3, partido.getGoles_local());
        pstmt.setByte(4, partido.getGoles_visitante());
        pstmt.setDate(5, new java.sql.Date(partido.getFecha().getTime()));
        pstmt.setTime(6, new java.sql.Time(partido.getHora().getTime()));
        pstmt.setByte(7, partido.getId_equipo_local());
        pstmt.setByte(8, partido.getId_equipo_visitante());
        pstmt.setByte(9, partido.getJornada());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        pstmt.close();
        return status;
    }

    public boolean eliminar(PartidoDTO partido) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_DELETE);
        pstmt.setByte(1, partido.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public boolean actualizar(PartidoDTO partido) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_UPDATE);
        pstmt.setString(1, partido.getEquipo_local());
        pstmt.setString(2, partido.getEquipo_visitante());
        pstmt.setByte(3, partido.getGoles_local());
        pstmt.setByte(4, partido.getGoles_visitante());
        pstmt.setDate(5, new java.sql.Date(partido.getFecha().getTime()));
        pstmt.setTime(6, new java.sql.Time(partido.getHora().getTime()));
        pstmt.setByte(7, partido.getId_equipo_local());
        pstmt.setByte(8, partido.getId_equipo_visitante());
        pstmt.setByte(9, partido.getJornada());
        pstmt.setByte(10, partido.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public PartidoDTO buscar(PartidoDTO partido) throws SQLException, Exception {
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT);
        ResultSet result = null;
        pstmt.setByte(1, partido.getId());
        result = pstmt.executeQuery();
        if (result.next()) {
            partido.setEquipo_local(result.getString(1));
            partido.setEquipo_visitante(result.getString(2));
            partido.setGoles_local(result.getByte(3));
            partido.setGoles_visitante(result.getByte(4));
            partido.setFecha(result.getDate(5));
            partido.setHora(result.getTime(6));
            partido.setId_equipo_local(result.getByte(7));
            partido.setId_equipo_visitante(result.getByte(8));
            partido.setJornada(result.getByte(9));
            partido.setId(result.getByte(10));
        } else {
            partido = null;
        }
        return partido;
    }

    public List<PartidoDTO> listar() throws SQLException, Exception {
        List<PartidoDTO> partidos = new LinkedList<PartidoDTO>();
        ResultSet result = null;
        PartidoDTO partido;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT_All);
        result = pstmt.executeQuery();
        while (result.next()) {
            partido = new PartidoDTO();
            partido.setEquipo_local(result.getString(1));
            partido.setEquipo_visitante(result.getString(2));
            partido.setGoles_local(result.getByte(3));
            partido.setGoles_visitante(result.getByte(4));
            partido.setFecha(result.getDate(5));
            partido.setHora(result.getTime(6));
            partido.setId_equipo_local(result.getByte(7));
            partido.setId_equipo_visitante(result.getByte(8));
            partido.setJornada(result.getByte(9));
            partido.setId(result.getByte(10));
            partidos.add(partido);
        }
        return partidos;
    }
}
