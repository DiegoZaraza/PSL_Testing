
package proyectoliga.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.JugadorDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class JugadorDAO {
    private static final String SQL_INSERT
            = "INSERT INTO jugador ("
            + "paterno, materno, nombre, posicion, numero, tarjetas_amarillas, tarjetas_rojas, goles, equipo"
            + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_SELECT
            = "SELECT paterno, materno, nombre, posicion, numero, tarjetas_amarillas, tarjetas_rojas, goles, equipo "
            + "  FROM jugador where id= ?";
    private static final String SQL_SELECT_All
            = "SELECT paterno, materno, nombre, posicion, numero, tarjetas_amarillas, tarjetas_rojas, goles, equipo, id "
            + "FROM jugador";
    private static final String SQL_UPDATE
            = "UPDATE jugador SET "
            + "paterno = ?, materno = ?, nombre = ?, posicion = ?, numero = ?, tarjetas_amarillas = ?, tarjetas_rojas = ?, goles = ?, equipo = ? "
            + " WHERE "
            + "id = ? ";
    private static final String SQL_DELETE
            = "DELETE FROM jugador "
            + "WHERE id = ?";

    private DBConnection conexion;

    public JugadorDAO(DBConnection conexion) {
        this.conexion = conexion;
    }

    public boolean insertar(JugadorDTO jugador) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_INSERT);
        pstmt.setString(1, jugador.getPaterno());
        pstmt.setString(2, jugador.getMaterno());
        pstmt.setString(3, jugador.getNombre());
        pstmt.setString(4, jugador.getPosicion());
        pstmt.setByte(5, jugador.getNumero());
        pstmt.setByte(6, jugador.getTarjetas_amarillas());
        pstmt.setByte(7, jugador.getTarjetas_rojas());
        pstmt.setByte(8, jugador.getGoles());
        pstmt.setByte(9, jugador.getEquipo());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        pstmt.close();
        return status;
    }

    public boolean eliminar(JugadorDTO jugador) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_DELETE);
        pstmt.setByte(1, jugador.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public boolean actualizar(JugadorDTO jugador) throws SQLException, Exception {
        boolean status = false;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_UPDATE);
        pstmt.setString(1, jugador.getPaterno());
        pstmt.setString(2, jugador.getMaterno());
        pstmt.setString(3, jugador.getNombre());
        pstmt.setString(4, jugador.getPosicion());
        pstmt.setByte(5, jugador.getNumero());
        pstmt.setByte(6, jugador.getTarjetas_amarillas());
        pstmt.setByte(7, jugador.getTarjetas_rojas());
        pstmt.setByte(8, jugador.getGoles());
        pstmt.setByte(9, jugador.getEquipo());
        pstmt.setByte(10, jugador.getId());
        if (pstmt.executeUpdate() == 1) {
            status = true;
        }
        return status;
    }

    public JugadorDTO buscar(JugadorDTO jugador) throws SQLException, Exception {
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT);
        ResultSet result = null;
        pstmt.setByte(1, jugador.getId());
        result = pstmt.executeQuery();
        if (result.next()) {
            jugador.setPaterno(result.getString(1));
            jugador.setMaterno(result.getString(2));
            jugador.setNombre(result.getString(3));
            jugador.setPosicion(result.getString(4));
            jugador.setNumero(result.getByte(5));
            jugador.setTarjetas_amarillas(result.getByte(6));
            jugador.setTarjetas_rojas(result.getByte(7));
            jugador.setGoles(result.getByte(8));
            jugador.setEquipo(result.getByte(9));
            jugador.setId(result.getByte(10));
        } else {
            jugador = null;
        }
        return jugador; 
    }

    public List<JugadorDTO> listar() throws SQLException, Exception {
        List<JugadorDTO> jugadores = new LinkedList<JugadorDTO>();
        ResultSet result = null;
        JugadorDTO jugador;
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT_All);
        result = pstmt.executeQuery();
        while (result.next()) {
            jugador = new JugadorDTO();
            jugador.setPaterno(result.getString(1));
            jugador.setMaterno(result.getString(2));
            jugador.setNombre(result.getString(3));
            jugador.setPosicion(result.getString(4));
            jugador.setNumero(result.getByte(5));
            jugador.setTarjetas_amarillas(result.getByte(6));
            jugador.setTarjetas_rojas(result.getByte(7));
            jugador.setGoles(result.getByte(8));
            jugador.setEquipo(result.getByte(9));
            jugador.setId(result.getByte(10));
            jugadores.add(jugador);
        }
        return jugadores;
    }
}
