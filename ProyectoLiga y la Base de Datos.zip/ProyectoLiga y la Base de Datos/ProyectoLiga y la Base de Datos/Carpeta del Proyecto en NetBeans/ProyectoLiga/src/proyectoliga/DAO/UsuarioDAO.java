/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoliga.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.UsuarioDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class UsuarioDAO {
    private static final String SQL_SELECT = "SELECT * FROM USUARIOS WHERE usuario = ? AND pass = ?";
    private DBConnection conexion;

    public UsuarioDAO(DBConnection conexion) {
        this.conexion = conexion;
    }
    
     public UsuarioDTO buscar(UsuarioDTO usuario) throws SQLException, Exception {
        PreparedStatement pstmt = conexion.getConnection().prepareStatement(SQL_SELECT);
        ResultSet result = null;
        pstmt.setString(1, usuario.getUsuario());
        pstmt.setString(2, usuario.getPass());
        result = pstmt.executeQuery();
        if (result.next()) {
            usuario.setTipo(result.getString(3));
        } else {
            usuario = null;
        }
        return usuario; 
    }
}
