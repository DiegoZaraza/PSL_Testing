
package proyectoliga.Test;

import java.util.logging.Level;
import java.util.logging.Logger;
import proyectoliga.DAO.JugadorDAO;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.JugadorDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class TestJugadorDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    try {
            DBConnection dbc = new DBConnection();
            JugadorDTO dto = new JugadorDTO();
            //Crear una instacia del DAO
            JugadorDAO dao = new JugadorDAO(dbc);

            dto.setPaterno("Rivera");
            dto.setMaterno("Montes");
            dto.setNombre("Fabiano");
            dto.setPosicion("Delantero");
            dto.setNumero((byte) 13);
            dto.setTarjetas_amarillas((byte) 03);
            dto.setTarjetas_rojas((byte) 01);
            dto.setGoles((byte) 04);
            dto.setEquipo((byte) 11);

            dao.insertar(dto);

        } catch (Exception ex) {
            Logger.getLogger(TestTorneoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
