package proyectoliga.Test;

import java.util.logging.Level;
import java.util.logging.Logger;
import proyectoliga.DAO.TorneoDAO;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.TorneoDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class TestTorneoDAO {
/**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            DBConnection dbc = new DBConnection();
            TorneoDTO dto = new TorneoDTO();
            //Crear una instacia del DAO
            TorneoDAO dao = new TorneoDAO(dbc);

            dto.setNombre("LigaBBA");
            dto.setTemporada("2015-2016");
            dto.setInicio(new java.sql.Date(2016, 05, 11));
            dto.setFin(new java.sql.Date(2016, 04, 23)); 
            dto.setCampeon("Indios");

            dao.insertar(dto);

            //   System.out.println(dao.listar().toString());
        } catch (Exception ex) {
            Logger.getLogger(TestTorneoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
