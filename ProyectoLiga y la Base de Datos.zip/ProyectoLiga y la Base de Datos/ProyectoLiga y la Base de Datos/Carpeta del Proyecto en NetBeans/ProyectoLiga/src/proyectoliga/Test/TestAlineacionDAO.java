/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoliga.Test;

import java.util.logging.Level;
import java.util.logging.Logger;
import proyectoliga.DAO.AlineacionDAO;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.AlineacionDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class TestAlineacionDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                try {
            DBConnection dbc = new DBConnection();
            AlineacionDTO dto = new AlineacionDTO();
            //Crear una instacia del DAO
            AlineacionDAO dao = new AlineacionDAO(dbc);

            dto.setId_partido((byte) 10);
            dto.setId_jugador((byte) 15);
            dto.setInicio(new java.sql.Time(10, 20, 45));
            dto.setFin(new java.sql.Time(06, 04, 23));
            dto.setPuesto("Delantero");

            dao.insertar(dto);

            //   System.out.println(dao.listar().toString());
        } catch (Exception ex) {
            Logger.getLogger(TestTorneoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
