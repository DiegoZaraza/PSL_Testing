
package proyectoliga.Test;

import java.util.logging.Level;
import java.util.logging.Logger;
import proyectoliga.DAO.PartidoDAO;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.PartidoDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class TestPartidoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            DBConnection dbc = new DBConnection();
            PartidoDTO dto = new PartidoDTO();
            //Crear una instacia del DAO
            PartidoDAO dao = new PartidoDAO(dbc);

            dto.setEquipo_local("Guadalajara");
            dto.setEquipo_visitante("Unam");
            dto.setGoles_local((byte) 13);
            dto.setGoles_visitante((byte) 20);
            dto.setFecha(new java.sql.Date(2016, 04, 28));
            dto.setHora(new java.sql.Time(04, 56, 10));
            dto.setId_equipo_local((byte) 04);
            dto.setId_equipo_visitante((byte) 11);
            dto.setJornada((byte) 03);

            dao.insertar(dto);

        } catch (Exception ex) {
            Logger.getLogger(TestTorneoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
