
package proyectoliga.Test;

import java.util.logging.Level;
import java.util.logging.Logger;
import proyectoliga.DAO.EquipoDAO;
import proyectoliga.DBC.DBConnection;
import proyectoliga.DTO.EquipoDTO;

/**
 *
 * @author EstephanyJaneth
 */
public class TestEquipoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            DBConnection dbc = new DBConnection();
            EquipoDTO dto = new EquipoDTO();
            //Crear una instacia del DAO
            EquipoDAO dao = new EquipoDAO(dbc);

            dto.setNombre("Indios");
            dto.setMascota("Indio");
            dto.setEstadio("Los Altos");
            dto.setCiudad("Monterrey");
            dto.setPartidos_jugados((byte) 20);
            dto.setPartidos_ganados((byte) 17);
            dto.setPartidos_empatados((byte) 02);
            dto.setPartidos_perdidos((byte) 01);
            dto.setGoles_favor((byte) 11);
            dto.setGoles_encontra((byte) 8);
            dto.setDiferencia_goles((byte) 03);
            dto.setPuntos((byte) 22);
            dto.setLiga((byte) 01);

            dao.insertar(dto);

        } catch (Exception ex) {
            Logger.getLogger(TestTorneoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
