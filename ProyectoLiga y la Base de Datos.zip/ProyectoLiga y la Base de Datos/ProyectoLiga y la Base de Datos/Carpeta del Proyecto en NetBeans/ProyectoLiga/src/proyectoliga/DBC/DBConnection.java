package proyectoliga.DBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author EstephanyJaneth
 */
public class DBConnection {

   public static String bd = "liga";
   public static String login = "root";
   public static String password = "";
   public static String url = "jdbc:mysql://localhost/" + bd;

   private Connection connection;

    /**
     * Constructor de DbConnection
     */
    public DBConnection() {
        try {
            //obtenemos el driver de para mysql
            Class.forName("com.mysql.jdbc.Driver");
            //obtenemos la conexión
            connection = DriverManager.getConnection(url, login, password);

            if (connection != null) {
                System.out.println("Conexión a base de datos " + bd + " OK\n");
                //JOptionPane.showMessageDialog(null, "Conexión a base de datos "+bd+" OK");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"ffff"+e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            //JOptionPane.showMessageDialog(null,e);
        } catch (Exception e) {
            System.out.println(e);
            //JOptionPane.showMessageDialog(null,e);
        }
    }

    /**
     * Permite retornar la conexión
     */
    public Connection getConnection() {
        return connection;
    }

    public void desconectar() {
        connection = null;
    }
}
