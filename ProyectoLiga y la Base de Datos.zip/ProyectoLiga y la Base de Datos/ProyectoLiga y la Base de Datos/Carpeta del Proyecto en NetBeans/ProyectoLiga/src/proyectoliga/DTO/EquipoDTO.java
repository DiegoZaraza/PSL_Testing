package proyectoliga.DTO;

/**
 *
 * @author EstephanyJaneth
 */
public class EquipoDTO {

    private Byte id;
    private String nombre;
    private String mascota;
    private String estadio;
    private String ciudad;
    private Byte partidos_jugados;
    private Byte partidos_ganados;
    private Byte partidos_empatados;
    private Byte partidos_perdidos;
    private Byte goles_favor;
    private Byte goles_encontra;
    private Byte diferencia_goles;
    private Byte puntos;
    private Byte liga;

    public EquipoDTO() {
    }

    public EquipoDTO(Byte id, String nombre, String mascota, String estadio, String ciudad, Byte partidos_jugados, Byte partidos_ganados, Byte partidos_empatados, Byte partidos_perdidos, Byte goles_favor, Byte goles_encontra, Byte diferencia_goles, Byte puntos, Byte liga) {
        this.id = id;
        this.nombre = nombre;
        this.mascota = mascota;
        this.estadio = estadio;
        this.ciudad = ciudad;
        this.partidos_jugados = partidos_jugados;
        this.partidos_ganados = partidos_ganados;
        this.partidos_empatados = partidos_empatados;
        this.partidos_perdidos = partidos_perdidos;
        this.goles_favor = goles_favor;
        this.goles_encontra = goles_encontra;
        this.diferencia_goles = diferencia_goles;
        this.puntos = puntos;
        this.liga = liga;
    }

    public Byte getId() {
        return id;
    }

    public void setId(Byte id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMascota() {
        return mascota;
    }

    public void setMascota(String mascota) {
        this.mascota = mascota;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public Byte getPartidos_jugados() {
        return partidos_jugados;
    }

    public void setPartidos_jugados(Byte partidos_jugados) {
        this.partidos_jugados = partidos_jugados;
    }

    public Byte getPartidos_ganados() {
        return partidos_ganados;
    }

    public void setPartidos_ganados(Byte partidos_ganados) {
        this.partidos_ganados = partidos_ganados;
    }

    public Byte getPartidos_empatados() {
        return partidos_empatados;
    }

    public void setPartidos_empatados(Byte partidos_empatados) {
        this.partidos_empatados = partidos_empatados;
    }

    public Byte getPartidos_perdidos() {
        return partidos_perdidos;
    }

    public void setPartidos_perdidos(Byte partidos_perdidos) {
        this.partidos_perdidos = partidos_perdidos;
    }

    public Byte getGoles_favor() {
        return goles_favor;
    }

    public void setGoles_favor(Byte goles_favor) {
        this.goles_favor = goles_favor;
    }

    public Byte getGoles_encontra() {
        return goles_encontra;
    }

    public void setGoles_encontra(Byte goles_encontra) {
        this.goles_encontra = goles_encontra;
    }

    public Byte getDiferencia_goles() {
        return diferencia_goles;
    }

    public void setDiferencia_goles(Byte diferencia_goles) {
        this.diferencia_goles = diferencia_goles;
    }

    public Byte getPuntos() {
        return puntos;
    }

    public void setPuntos(Byte puntos) {
        this.puntos = puntos;
    }

    public Byte getLiga() {
        return liga;
    }

    public void setLiga(Byte liga) {
        this.liga = liga;
    }
    
    
}
