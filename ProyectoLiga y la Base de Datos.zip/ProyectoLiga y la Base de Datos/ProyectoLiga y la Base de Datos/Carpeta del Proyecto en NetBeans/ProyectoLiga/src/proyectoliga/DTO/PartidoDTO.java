/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoliga.DTO;

import java.sql.Date;
import java.sql.Time;

/**
 *
 * @author EstephanyJaneth
 */
public class PartidoDTO {
    private Byte id;
    private String equipo_local;
    private String equipo_visitante;
    private Byte goles_local;
    private Byte goles_visitante;
    private Date fecha;
    private Time hora;
    private Byte id_equipo_local;
    private Byte id_equipo_visitante;
    private Byte jornada;


    public PartidoDTO(Byte id, String equipo_local, String equipo_visitante, Byte goles_local, Byte goles_visitante, Date fecha, Time hora, Byte id_equipo_local, Byte id_equipo_visitante, Byte jornada) {
        this.id = id;
        this.equipo_local = equipo_local;
        this.equipo_visitante = equipo_visitante;
        this.goles_local = goles_local;
        this.goles_visitante = goles_visitante;
        this.fecha = fecha;
        this.hora = hora;
        this.id_equipo_local = id_equipo_local;
        this.id_equipo_visitante = id_equipo_visitante;
        this.jornada = jornada;
    }

    public PartidoDTO() {
    }

  

    public Byte getId() {
        return id;
    }

    public void setId(Byte id) {
        this.id = id;
    }

    public String getEquipo_local() {
        return equipo_local;
    }

    public void setEquipo_local(String equipo_local) {
        this.equipo_local = equipo_local;
    }

    public String getEquipo_visitante() {
        return equipo_visitante;
    }

    public void setEquipo_visitante(String equipo_visitante) {
        this.equipo_visitante = equipo_visitante;
    }

    public Byte getGoles_local() {
        return goles_local;
    }

    public void setGoles_local(Byte goles_local) {
        this.goles_local = goles_local;
    }

    public Byte getGoles_visitante() {
        return goles_visitante;
    }

    public void setGoles_visitante(Byte goles_visitante) {
        this.goles_visitante = goles_visitante;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public Byte getId_equipo_local() {
        return id_equipo_local;
    }

    public void setId_equipo_local(Byte id_equipo_local) {
        this.id_equipo_local = id_equipo_local;
    }

    public Byte getId_equipo_visitante() {
        return id_equipo_visitante;
    }

    public void setId_equipo_visitante(Byte id_equipo_visitante) {
        this.id_equipo_visitante = id_equipo_visitante;
    }

    public Byte getJornada() {
        return jornada;
    }

    public void setJornada(Byte jornada) {
        this.jornada = jornada;
    }
}
    