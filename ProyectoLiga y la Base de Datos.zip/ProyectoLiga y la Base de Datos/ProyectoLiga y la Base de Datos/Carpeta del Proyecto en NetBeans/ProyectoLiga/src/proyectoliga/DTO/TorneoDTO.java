
package proyectoliga.DTO;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author EstephanyJaneth
 */
public class TorneoDTO implements Serializable {

    private Byte id;
    private String nombre;
    private String temporada;
    private java.util.Date inicio;
    private java.util.Date fin;
    private String campeon;

    public TorneoDTO() {
    }

    public TorneoDTO(Byte id, String nombre, String temporada, Date inicio, Date fin, String campeon, Byte equipo) {
        this.id = id;
        this.nombre = nombre;
        this.temporada = temporada;
        this.inicio = inicio;
        this.fin = fin;
        this.campeon = campeon;
    }

    public Byte getId() {
        return id;
    }

    public void setId(Byte id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTemporada() {
        return temporada;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    public java.util.Date getInicio() {
        return inicio;
    }

    public void setInicio(java.util.Date inicio) {
        this.inicio = inicio;
    }

    public java.util.Date getFin() {
        return fin;
    }

    public void setFin(java.util.Date fin) {
        this.fin = fin;
    }

    public String getCampeon() {
        return campeon;
    }

    public void setCampeon(String campeon) {
        this.campeon = campeon;
    }

    public TorneoDTO buscar(TorneoDTO torneo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "TorneoDTO{" + "id=" + id + ", nombre=" + nombre + ", temporada=" + temporada + ", inicio=" + inicio + ", fin=" + fin + ", campeon=" + campeon + '}';
    }
    
}