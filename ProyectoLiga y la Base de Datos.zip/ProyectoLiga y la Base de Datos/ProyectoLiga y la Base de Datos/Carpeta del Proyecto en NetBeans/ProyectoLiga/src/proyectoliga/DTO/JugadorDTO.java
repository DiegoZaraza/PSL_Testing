/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoliga.DTO;

/**
 *
 * @author EstephanyJaneth
 */
public class JugadorDTO {
    private Byte id;
    private String paterno;
    private String materno;
    private String nombre;
    private String posicion;
    private Byte numero;
    private Byte tarjetas_amarillas;
    private Byte tarjetas_rojas;
    private Byte goles;
    private Byte equipo;

    public JugadorDTO() {
    }

    public JugadorDTO(Byte id, String paterno, String materno, String nombre, String posicion, Byte numero, Byte tarjetas_amarillas, Byte tarjetas_rojas, Byte goles, Byte equipo) {
        this.id = id;
        this.paterno = paterno;
        this.materno = materno;
        this.nombre = nombre;
        this.posicion = posicion;
        this.numero = numero;
        this.tarjetas_amarillas = tarjetas_amarillas;
        this.tarjetas_rojas = tarjetas_rojas;
        this.goles = goles;
        this.equipo = equipo;
    }

    public Byte getId() {
        return id;
    }

    public void setId(Byte id) {
        this.id = id;
    }

    public String getPaterno() {
        return paterno;
    }

    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public Byte getNumero() {
        return numero;
    }

    public void setNumero(Byte numero) {
        this.numero = numero;
    }

    public Byte getTarjetas_amarillas() {
        return tarjetas_amarillas;
    }

    public void setTarjetas_amarillas(Byte tarjetas_amarillas) {
        this.tarjetas_amarillas = tarjetas_amarillas;
    }

    public Byte getTarjetas_rojas() {
        return tarjetas_rojas;
    }

    public void setTarjetas_rojas(Byte tarjetas_rojas) {
        this.tarjetas_rojas = tarjetas_rojas;
    }

    public Byte getGoles() {
        return goles;
    }

    public void setGoles(Byte goles) {
        this.goles = goles;
    }

    public Byte getEquipo() {
        return equipo;
    }

    public void setEquipo(Byte equipo) {
        this.equipo = equipo;
    }
}