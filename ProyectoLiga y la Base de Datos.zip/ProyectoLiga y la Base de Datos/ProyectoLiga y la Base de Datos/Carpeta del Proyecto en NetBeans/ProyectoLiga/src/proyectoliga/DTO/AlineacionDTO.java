/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoliga.DTO;

import java.sql.Time;

/**
 *
 * @author EstephanyJaneth
 */
public class AlineacionDTO {
    private Byte id_partido;
    private Byte id_jugador;
    private Time inicio;
    private Time fin;
    private String puesto;

    public AlineacionDTO() {
    }

    public AlineacionDTO(Byte id_partido, Byte id_jugador, Time inicio, Time fin, String puesto) {
        this.id_partido = id_partido;
        this.id_jugador = id_jugador;
        this.inicio = inicio;
        this.fin = fin;
        this.puesto = puesto;
    }

    public Byte getId_partido() {
        return id_partido;
    }

    public void setId_partido(Byte id_partido) {
        this.id_partido = id_partido;
    }

    public Byte getId_jugador() {
        return id_jugador;
    }

    public void setId_jugador(Byte id_jugador) {
        this.id_jugador = id_jugador;
    }

    public Time getInicio() {
        return inicio;
    }

    public void setInicio(Time inicio) {
        this.inicio = inicio;
    }

    public Time getFin() {
        return fin;
    }

    public void setFin(Time fin) {
        this.fin = fin;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    
}
